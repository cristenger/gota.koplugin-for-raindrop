local _ = require("gettext")

return {
  name        = "gota",                                  
  fullname    = _("Gota"),                            
  description = _("Con Gota lee y gestiona tus marcadores de Raindrop.io desde KOReader!")
}