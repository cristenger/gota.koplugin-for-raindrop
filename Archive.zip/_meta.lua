local _ = require("gettext")

return {
  name        = "raindrop",                                  
  fullname    = _("Raindrop.io"),                            
  description = _("Lee y gestiona tus marcadores de Raindrop.io desde KOReader!")
}